package com.OrderManager.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	
	@Id
	String productId;
	@Column
	String productName;
	@Column
	String sku;
	@Column
	int locationID;
	@Column
	Float weight;
	@Column
	String status;
	
	public Product() {
	}
	
	
	public Product(String productId, String productName, String sku, int locationID, Float weight, String status) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.sku = sku;
		this.locationID = locationID;
		this.weight = weight;
		this.status = status;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public int getLocationID() {
		return locationID;
	}
	public void setLocationID(int locationID) {
		this.locationID = locationID;
	}
	public Float getWeight() {
		return weight;
	}
	public void setWeight(Float weight) {
		this.weight = weight;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", sku=" + sku + ", locationID="
				+ locationID + ", weight=" + weight + ", status=" + status + "]";
	}
	

}
