package com.OrderManager.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.OrderManager.Model.Product;

@RestController
@RequestMapping("/OrderManager")
public class ProductController {

	@GetMapping("/{sku}")
	public Product ProductInfo(@PathVariable String sku) {
		return getProductInfo(sku);
	}
	
	private Product getProductInfo(String sku) {
		return new Product("PROD1", "PROD1","Prod1", 12345, 24.00F ,"Delivered");
	}
	
	@GetMapping("/hello")
	private String sayHello() {
		return "Hello Users";
	}
	
	@GetMapping("/allProduct")
	private List<Product> getProducts(){
		
		List<Product> list = new ArrayList<Product>();
		list.add(new Product("PROD1", "PROD1","Prod1", 12345, 24.00F ,"Delivered"));
		list.add(new Product("PROD2", "PROD2","Prod2", 12346, 24.00F ,"Delivered"));
		list.add(new Product("PROD3", "PROD3","Prod3", 12347, 24.00F ,"Delivered"));
		list.add(new Product("PROD4", "PROD4","Prod4", 12348, 24.00F ,"Delivered"));
		
		
		return list;
	}
	
}
